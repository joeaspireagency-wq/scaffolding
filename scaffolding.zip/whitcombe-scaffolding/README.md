# Whitcombe Scaffolding (demonstration website)

A single-page website prototype for a fictional UK scaffolder. One file, no build step, no dependencies.

## Put it on GitHub Pages
1. Create a new repository on GitHub.
2. Upload `index.html` (and this README) to the repository root.
3. Go to Settings > Pages, set the source to "Deploy from a branch", choose `main` and `/ (root)`, then save.
4. After a minute the site is live at `https://<your-username>.github.io/<repository-name>/`.

## Edit it
Open `index.html` and search for `SITE` near the start of the script. Business name, phone, email, areas, opening hours and hero copy are all there. The other content blocks (services, prices, guarantees, FAQs, reviews) sit just below it.

## Notes
- The quote form is a demonstration only. It makes no network request. The place to connect a real form service (Web3Forms or Formspree) is marked in the script, in the `submitQuote` function.
- Images are drawn illustrations used as placeholders. Replace them with real project photographs.
- Reviews, figures, prices and credentials are fictional. Replace them before using this for a real business.
- Fonts (Barlow Condensed and Inter) load from Google Fonts.
